@extends('layouts.app')

@section('content')
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">
            <b>Selamat datang di aplikasi sistem penanganan masalah invalid data resi pada jasa pengiriman di kota
                Makassar</b>
        </div>
    </div>
@endsection
